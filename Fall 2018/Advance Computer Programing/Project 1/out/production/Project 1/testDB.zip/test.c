#include<stdio.h>

main()
{
  int x; char y,c2;
  
  scanf("%d", &x);
  printf("%d\n", x);
  scanf("%c",&c2);
  scanf("%c", &y);
  printf("%c\n", y);
    
}