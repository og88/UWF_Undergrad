import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;

/**
 * This class is the underlying class to both Server and Client, and is used by both once
 * a connection has been established.
 * 
 * @author Gilbert Petris
 */
public class Connection {
	private Socket socket = null;
	private ArrayList<Listener> cListeners = new ArrayList<Listener>();

	private long threadSleepTime = 200;
	private long commTimeout = 10000;
	private long otherSideTimeout = 1000;
	private long lastComm = 0;
	private boolean connected = true;
	
	/**
	 * Listener interface for the classes using this class to implement to receive incomming messages.
	 * 
	 * @author Gilbert Petris
	 */
	public static interface Listener {
		public void messageReceived(String message);
	}
	
	/**
	 * This class is the main running class that receives messages from the other side of the connection.
	 * 
	 * @author Gilbert Petris
	 */
	private class ConnectionRun implements Runnable {
		/**
		 * Default constructor, automatically starts a new Thread to listen for incomming messages.
		 */
		public ConnectionRun() {
			new Thread(this).start();
		}
		
		/**
		 * This method implements Runnable and is the method used to receive message from the other side
		 * of the connection.
		 */
		public void run() {
			try {
				BufferedReader message = new BufferedReader(new InputStreamReader(socket.getInputStream()));
				String line = "";
				while(connected) {
					while(message.ready()) {
						line = message.readLine();
						try {
							String cmd = line.trim().split(" ")[0];
							line = line.substring(cmd.length(), line.length()).trim();

							if (cmd.equals("CONNECTION")) {
								connectionMessage(line);
							} else if (cmd.equals("CLIENT")) {
								listenerMessage(line);
							}
						} catch (Exception e) { }
					}
					
					try {
						Thread.sleep(threadSleepTime);
					} catch (InterruptedException e) { }
				}
			} catch (IOException e) { } finally {
				try {
					socket.close();
				} catch (IOException e) {}
			}
		}
	}
	
	/**
	 * This class checks to make sure that the connection has not timed out.
	 * 
	 * @author Gilbert Petris
	 */
	private class TimeoutCloseRun implements Runnable {
		/**
		 * Default constructor, automatically starts a new Thread to check if the connection has timed out.
		 */
		public TimeoutCloseRun() {
			new Thread(this).start();
		}
		
		/**
		 * This method implements Runnable and is the method used to check if the connection has timed out.
		 */
		public void run() {
			while (connected) {
				try {
					Thread.sleep(commTimeout);
				} catch (InterruptedException e) { }
			
				if (System.currentTimeMillis() > lastComm + commTimeout) {
					close();
				}
			}
		}
	}
	
	/**
	 * This class sends a timeout message periodically to the other side of the connection.
	 * 
	 * @author Gilbert Petris
	 */
	private class TimeoutSendRun implements Runnable {
		/**
		 * Default constructor, automatically starts a new Thread to send timeout messages.
		 */
		public TimeoutSendRun() {
			new Thread(this).start();
		}
		
		/**
		 * This method implements Runnable and is the method used to sent timeout messages to the other side
		 * of the connection.
		 */
		public void run() {
			while (connected) {
				try {
					Thread.sleep(otherSideTimeout / 2);
				} catch (InterruptedException e) { }
				
				sendMessage("PING", false);
			}
		}
	}
	
	/**
	 * Creates a new connection and returns null if the connection was unsuccessful.
	 * 
	 * @param nSocket The socket to create the connection with.
	 * @return a Connection object if successfull, null if not.
	 */
	public static Connection createConnection(Socket nSocket) {
		try {
			Connection nConnection = new Connection(nSocket);
			return nConnection;
		} catch (InstantiationException e) {
			return null;
		}
	}

	/**
	 * Creates a new connection, and can only be created by the createConnection() method.
	 * 
	 * @param nSocket The socket to create the connection with.
	 * @throws InstantiationException if creation was unsuccessful.
	 */
	private Connection(Socket nSocket) throws InstantiationException {
		socket = nSocket;
		try {
			socket.setKeepAlive(true);
		} catch (SocketException e) { }
		
		new ConnectionRun();
		new TimeoutSendRun();
		new TimeoutCloseRun();
		
		sendMessage("SET TIMEOUT " + commTimeout, false);
	}
	
	/**
	 * Adds a connection listener to the connection.
	 * 
	 * @param nListener The connection listener to add.
	 */
	public void addConnectionListener(Listener nListener) {
		cListeners.add(nListener);
	}
	
	/**
	 * Removes a connection listener from the connection.
	 * 
	 * @param nListener The connection listener to remove.
	 */
	public void removeConnectionListener(Listener nListener) {
		cListeners.remove(nListener);
	}
	
	/**
	 * Sends a message to the client other side of the connection.
	 * 
	 * @param message the message to be sent.
	 * @return true if the message was successful, false if not.
	 */
	public boolean sendMessage(String message) {
		return sendMessage(message, true);
	}
	
	/**
	 * Sends a message to the other side of the connection, allowing specification
	 * of weather the client or the connection gets the message.
	 * 
	 * @param message the message to be sent.
	 * @param toClient true to send to client, false to send to connction.
	 * @return true if the message was successful, false if not.
	 */
	private boolean sendMessage(String message, boolean toClient) {
		try {
			BufferedWriter output = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
			
			output.write((toClient ? "CLIENT" : "CONNECTION") + " ");
			output.write(message);
			output.newLine();
			output.flush();
			
			return true;
		} catch (IOException e) {
			return false;
		}
	}
	
	/**
	 * Closes the connection.
	 */
	public void close() {
		if (connected) {
			connected = false;
			listenerMessage("END");
	
			try {
				socket.close();
			} catch (IOException e) { }
		}
	}
	
	/**
	 * Interprets a connection message from the other side of the connection.
	 * 
	 * @param message the message.
	 */
	private void connectionMessage(String message) {
		try {
			String cmd = message.trim().split(" ")[0];
			message = message.trim().substring(cmd.length(), message.length()).trim();
			if (cmd.equals("PING")) {
				lastComm = System.currentTimeMillis();
			} else if (cmd.equals("SET")) {
				cmd = message.trim().split(" ")[0];
				message = message.trim().substring(cmd.length(), message.length()).trim();
				
				if (cmd.equals("TIMEOUT")) {
					otherSideTimeout = Integer.valueOf(message);
				}
			}
		} catch (Exception e) { }
	}
	
	/**
	 * Gets the hostname that this connection is connected to.
	 * 
	 * @return the hostname.
	 */
	public String getConnectedHost() {
		return socket.getInetAddress().getHostAddress();
	}
	
	/**
	 * Gets the port of the host that this connection is connected to.
	 * 
	 * @return the port number.
	 */
	public int getConnectedPort() {
		return socket.getPort();
	}
	
	/**
	 * Sends a message to all the connection listeners.
	 * 
	 * @param message the message to send to the connection listeners.
	 */
	private void listenerMessage(String message) {
		for (int loop = 0; loop < cListeners.size(); loop++) {
			cListeners.get(loop).messageReceived(message);
		}
	}
}