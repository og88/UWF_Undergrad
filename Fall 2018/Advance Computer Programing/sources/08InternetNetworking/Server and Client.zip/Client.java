import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * This class sets up a client connection to connect to a server.
 * 
 * @author Gilbert Petris
 */
public class Client {
	private InetAddress serverAddress = null;
	private Socket socket = null;
	private Connection connection = null;
	
	/**
	 * Creates a new client and connects to the specified server.&nbsp;Returns null
	 * if the connection was unsuccessful.
	 * 
	 * @param hostname The host name or IP address to connect to.
	 * @param port The port number of the host to connect to.
	 * @return a Client object if connection was successful, null if unsuccessful.
	 */
	public static Client createClient(String hostname, int port) {
		try {
			Client rClient = new Client(hostname, port);
			return rClient;
		} catch (InstantiationException e) {
			return null;
		}
	}
	
	/**
	 * Default Constructor, can only be instantiated through the createClient() method.
	 * 
	 * @param hostname The host name or IP address to connect to.
	 * @param nPort The port number of the host to connect to.
	 * @throws InstantiationException if the connection was unsuccessful.
	 */
	private Client(String hostname, int nPort) throws InstantiationException {
		try {
			serverAddress =  InetAddress.getByName(hostname);
			socket = new Socket(serverAddress, nPort);
			if ((connection = Connection.createConnection(socket)) == null) {
				throw new InstantiationException();
			}
		} catch (UnknownHostException e) {
			throw new InstantiationException();
		} catch (IOException e) {
			throw new InstantiationException();
		}
	}
	
	/**
	 * Sends a message to the other side of the connection.
	 * 
	 * @param message The message to send in String form.
	 */
	public void sendMessage(String message) {
		connection.sendMessage(message);
	}
	
	/**
	 * Adds a connection listener to the connection.
	 * 
	 * @param nListener The connection listener to add.
	 */
	public void addConnectionListener(Connection.Listener nListener) {
		connection.addConnectionListener(nListener);
	}
	
	/**
	 * Removes a connection listener from the connection.
	 * 
	 * @param nListener The connection listener to remove.
	 */
	public void removeConnectionListener(Connection.Listener nListener) {
		connection.removeConnectionListener(nListener);
	}
	
	/**
	 * Closes the connection.
	 */
	public void close() {
		connection.close();
	}
}
