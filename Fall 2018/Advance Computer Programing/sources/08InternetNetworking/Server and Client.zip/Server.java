import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * This class is used to set up a server connection to accept incomming connections.
 * 
 * @author Gilbert Petris
 */
public class Server {
	/**
	 * The interface for a server to implement to get incomming connections.
	 * 
	 * @author Gilbert Petris
	 */
	public static interface Listener {
		public void newConnection(Connection nConnection);
	}
	
	private ServerSocket server = null;
	private Thread serverThread = new Thread(new ServerRun());
	private Listener serverListener = null;
	private boolean accepting = false;
	
	/**
	 * ServerRun is the main thread that listenes for incomming connections.
	 * 
	 * @author Gilbert Petris
	 */
	private class ServerRun implements Runnable {
		/**
		 * Implementation of the Runnable interface to listen for incomming connections.
		 */
		public void run() {
			try {
				while(accepting) {
					Socket socket = server.accept();
					serverListener.newConnection(Connection.createConnection(socket));
				}
			} catch (IOException e) { } finally {
				try {
					server.close();
				} catch (IOException e) {}
			}
		}
	}
	
	/**
	 * Creates a new server connection with a listener specified.&nbsp;This method
	 * will return null if it is not able to create a new Server instance.
	 * 
	 * @param sl The listener this server will use.
	 * @return a Server object if the connection was successful, false otherwise.
	 */
	public static Server createServer(Listener sl) {
		try {
			Server nServer = new Server(sl);
			return nServer;
		} catch (InstantiationException e) {
			return null;
		}
	}
	
	/**
	 * Creates a new server connection with a listener specified.
	 * 
	 * @param sl The listener this server will use.
	 * @throws InstantiationException if the connection is not successful;
	 */
	private Server(Listener sl) throws InstantiationException {
		try {
			server = new ServerSocket(0);
		} catch (IOException e) {
			throw new InstantiationException();
		}
		
		serverListener = sl;
		setAccepting(true);
	}
	
	/**
	 * Sets weather the server is accepting new connections or not.
	 * 
	 * @param nAccept true to allow the server to accept new connections, false otherwise.
	 */
	public void setAccepting(boolean nAccept) {
		accepting = nAccept;
		
		if (accepting == true && !serverThread.isAlive()) {
			serverThread.start();
		}
	}
	
	/**
	 * Closes the server connection.
	 */
	public void close() {
		setAccepting(false);
		
		try {
			server.close();
		} catch (IOException e) { }
	}
	
	/**
	 * Gets the port that the server is listeneing on.
	 * 
	 * @return the local port that the server is listening on.
	 */
	public int getPort() {
		return server.getLocalPort();
	}
	
	/**
	 * Gets the local hostname of the computer.
	 * 
	 * @return the local hostname of the computer.
	 */
	public String getLocalHostname() {
		try {
			return InetAddress.getLocalHost().getCanonicalHostName();
		} catch (UnknownHostException e) {
			return "";
		}
	}
}
