import javax.swing.JFrame;

public class ColorViewer
{  
   public static void main(String[] args)
   {  
      ColorViewerFrame frame = new ColorViewerFrame();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setVisible(true);
   }
}

