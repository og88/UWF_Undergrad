import org.junit.Test;
import static org.junit.Assert.*;
import junit.framework.*;

public class TestJunit3 extends TestResult {
   // add the error
   public synchronized void addError(Test test, Throwable t) {
      System.out.println("  ^^^Adding basic error");
      super.addError((junit.framework.Test) test, t);
   }

   // add the failure
   public synchronized void addFailure(Test test, AssertionFailedError t) {
      System.out.println("  ^^^Adding AssertionFailure error");
      super.addFailure((junit.framework.Test) test, t);
   }
	
   @Test
   public void testAdd() {
      int num = 9;
      assertFalse(num > 6);
   }
   
   // Marks that the test run should stop.
   public synchronized void stop() {
      //stop the test here
   }
}
