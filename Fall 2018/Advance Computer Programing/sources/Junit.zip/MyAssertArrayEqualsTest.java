import org.junit.Test;
import static org.junit.Assert.*;
 
public class MyAssertArrayEqualsTest {
 
    //@Test
    public void myTestMethod() throws Exception
    {
      //assume that the below array represents expected result
      String[] expectedOutput = {"apple", "mango", "grape"};
      //assume that the below array is returned from the method
      //to be tested.
      String[] methodOutput = {"apple", "mangojunk", "grape"};
    
      try
      {
        assertArrayEquals(expectedOutput, methodOutput);
        System.out.println("success");
      }
      catch(Throwable e) 
      { 
        System.out.println("expected:" + createStringFromArray(expectedOutput));
        System.out.println("found:"+ createStringFromArray(methodOutput));
      }
    }
    
    public String createStringFromArray(String[] st)
    {
      String s = "";
      for(int i = 0; i < st.length; i++)
          s += st[i] + " ";
      return s;
    }
    
    public static void main(String[] args) throws Exception
    {
      MyAssertArrayEqualsTest m = new MyAssertArrayEqualsTest();
      m.myTestMethod();
    }
}
// See more at: http://www.java2novice.com/junit-examples/assert-array-equals/#sthash.THeWLYM0.dpuf