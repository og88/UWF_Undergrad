

import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;

public class TestJunit2 extends TestCase  {
   protected double fValue1;
   protected double fValue2;
   
   @Test
   public void testSet() {
      System.out.println("  ****Executing testSet");
      //count the number of test cases
		
      //test getName 
      String name = this.getName();
      System.out.println("Test Case Name = "+ name);

      //test setName
      this.setName("testNewSet");
      String newName = this.getName();
      System.out.println("Updated Test Case Name = "+ newName);
      
      assertEquals(fValue1,fValue2);
   }
   
   @Test
   public void testAdd() 
   {  
      System.out.println("  ****Executing testAdd");
      assertEquals(fValue1,fValue2);
   }
	
   @Before 
   public void setUp() {
   System.out.println("  ****Executing setup");
      fValue1 = 2.0;
      fValue2 = 3.0;
      System.out.println("No of Test Cases in TestJunit2 = "+ this.countTestCases());
   }
   
   
   
   //tearDown used to close the connection or clean up activities
   public void tearDown(  ) {
   }
}
