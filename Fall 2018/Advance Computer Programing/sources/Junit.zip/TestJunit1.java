import org.junit.Test;
import static org.junit.Assert.*;
import junit.framework.*;

public class TestJunit1 extends TestCase{

   @Test
   public void testIntAndString() {
      //test data
      System.out.println("No of Test Cases in TestJunit1 = "+ this.countTestCases());
      int num = 5;
      String temp = null;
      String str = "Junit is working fine";

      //check for equality
      assertEquals("Junit is working fine", str);
      
      //check for false condition
      assertFalse(num > 6);
    //  assertTrue(num > 6);
      //check for not null value
      assertNotNull(str);
   }
}
