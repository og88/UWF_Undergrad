import junit.framework.*;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.notification.Failure;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import java.util.Enumeration;

public class JunitTestSuite {
   public static void main(String[] a) {
      // add the test's in the suite
      TestSuite suite = new TestSuite(TestJunit1.class, TestJunit2.class, TestJunit3.class );
      TestResult result = new TestResult();
      suite.run(result);
      System.out.println("%%%%%SUMMARY%%%%%");
      System.out.println("Number of test cases = " + result.runCount());
      System.out.println("Number of failed test cases = " + result.failureCount());
      Enumeration failEnums = result.failures();

      while(failEnums.hasMoreElements())
        System.out.println("failure: " + failEnums.nextElement());
   }
}
