class Attribute
{
  String type;
  String name;
  
  public Attribute(String n, String t)
  {
    type = t;
    name = n;
  }
  
  public String toString()
  {
    return "name: " + name + " type: " + type;
  }
}