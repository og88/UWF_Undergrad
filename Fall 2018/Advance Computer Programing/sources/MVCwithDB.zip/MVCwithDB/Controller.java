/***************************************************
  Program: Controller.java
  Programmer: John Coffey with some modifications of
  a program from Big Java by Cay Horstmann
  Purpose: Illustrate one possible way to separate
  responsibilities in a Model/View/Controller system
 ***************************************************/
import java.io.File;

class Controller
{
 final int quit = 5;
 final int cancel = 0;
  private Model m;
  private View v;
  
   public Controller(String props) throws Exception
   {
       String query;
       m = new Model(props); 
       v = new View();
       getQueries();

   }
   
   
   public void getQueries()
   {
      int query;
      do
      {
         query = v.getQuery();
         System.out.println("this is the query [" + query + "]");
         if(query == cancel)
         {
           continue;
         }
         else if(query != quit)
         {
           System.out.println("issue query" + query);
           String result = m.issueBasicQuery(query);
           v.showResults(result);
         }
      }while(query != quit);
      try {
        m.closeConnection();
      }
      catch(Exception e) {}
   }

   public static void main(String[] args) throws Exception
   {   
      if (args.length == 0)
      {   
         System.out.println(
               "Usage: java -classpath driver_class_path" 
               + File.pathSeparator 
               + ". TestDB database.properties");
         return;
      }
      else 
		{
		   System.out.println("args[0] = " + args[0]);
         Controller c = new Controller(args[0]);
		}
    }
}