/***************************************************
  Program: Model.java
  Programmer: John Coffey with significant
  modifications of a program from Big Java by Cay 
  Horstmann
  Purpose: Illustrate model responsibilities to 
  issue queries and return results in a way that
  shields the other components in an MVC system 
  from the inner workings of resultSet class. 
 ***************************************************/

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.lang.reflect.*;
import java.util.ArrayList;

public class Model
{
private boolean runDB = true;

   ArrayList<Attribute> attributes = new ArrayList<Attribute>();

   ArrayList<Car> cars = new ArrayList<Car>();
   Statement stat; 
   Connection conn; 
   String[] queryList = {"",
                         "Select * from Test2",
                         "Select * from Test2 where manufacturer = 'Chevy'",
                         "Select * from Test2 where manufacturer = 'Dodge'",
                         "Select * from Test2 where weight > 2501"};
   public Model(String propertiesFile) throws Exception
   {
     SimpleDataSource.init(propertiesFile);
     conn = SimpleDataSource.getConnection();
     stat = conn.createStatement();     
     addCars();
     tryToDropTable(stat);
     createTable(stat);
     insertTuples(stat);

	  System.out.println("done with init");  
   }
   
   
   public void closeConnection() throws Exception
   {
     conn.close(); 
   }
   
   
   public void addCars()
   {
     for(int i = 0; i < 5; i++)
     {
       if(i < 3)
         cars.add(new Car(2500+i,"Chevy","Van",2));
       else
         cars.add(new Car(2500+i,"Dodge","Pickup",2));       
     } 
     for(Car c: cars)
       System.out.println(c);
   }

   public void tryToDropTable(Statement stat)
   {
  	  try {  
       if(runDB)
		   stat.execute("DROP TABLE Test2"); 
     }
	  catch (Exception e)
	  { System.out.println("drop failed"); }   
   }

  
  public void getAttributes() throws Exception
  {
    Class c = Class.forName("Car");
    Field f[] = c.getDeclaredFields();
    System.out.println("fields:");
    for (int i = 0; i < f.length; i++)
    {
      attributes.add(new Attribute(f[i].getName(),f[i].getType().toString()));
      //System.out.println("  " + f[i].toString());
    }
    for(Attribute a:attributes)
      System.out.println(a);
  }
 

 // "CREATE TABLE Test2 (Name CHAR(20),Age INTEGER)");
   
   public void createTable(Statement stat)
   {

      try
      {
        getAttributes();
         String query = "CREATE TABLE Test2 (";
         for(int i = 0; i < attributes.size(); i++)
         {
           Attribute a = attributes.get(i);
           query += a.name + " ";
           if(a.type.equals("double"))
             query += " DOUBLE";
           else if(a.type.equals("int"))
            query += " INTEGER";
           else
            query += " VARCHAR(50)";
           if(i<attributes.size()-1)
            query += ", ";
           else
             query += ")";
         }
         System.out.println("***query = [" + query + "]");
         if(runDB)
           stat.execute(query);
      }
	   catch (Exception e)
		{ System.out.println("create failed"); }   
   }
 
 // "INSERT INTO Test2 VALUES ('Romeo',27)"
   
   public void insertTuples(Statement stat)
   {
     try
      {
        Class cl = Class.forName("Car");
        Field fields[] = cl.getDeclaredFields();     
      
        String query;
        for(Car c: cars)
        {
          query = "INSERT INTO Test2 VALUES (";
          System.out.println("car loop" + c);
          Class cl1 = c.getClass();
          for(int i = 0; i < fields.length; i++)
           {
            Field f = fields[i];

            String name = f.getName();
            System.out.println("field loop name [" + name +"]");

            Field xField = c.getClass().getDeclaredField(name);
            xField.setAccessible(true);
            if(xField.getType().toString().equals("double"))
              query += xField.getDouble(c);
            else if(xField.getType().toString().equals("int"))
              query += xField.getInt(c);     
            else   // a string
              query += "'" + xField.get(c) + "'";
              
            if(i < fields.length - 1)
              query += ", ";
            else
              query +=")";
           }
           System.out.println("%%%" + query);
          if(runDB)
            stat.execute(query);
        }
      }
	   catch (Exception e)
	   { 
        System.out.println("insert failed");
        e.printStackTrace(); 
      }  
   }

   public String issueBasicQuery(int which)
   {
      String st = "";
      try
      {
         ResultSet result = stat.executeQuery(queryList[which]);
         System.out.println("%%%%%%%%" + which);
         ResultSetMetaData rsm = result.getMetaData();
			int cols = rsm.getColumnCount();
         st = "";
			  while(result.next())
			  {
			    for(int i = 1; i <= cols; i++)
               st += result.getString(i)+" ";
             st +='\n';      
			  }
         return st;
      }
		catch (Exception e)
		{ 
        System.out.println("query failed"); 
        return null;
      }   
   }




}
