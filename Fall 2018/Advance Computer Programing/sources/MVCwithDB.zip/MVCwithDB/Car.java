class Car
{
  private double weight;
  private String manufacturer;
  private String model;
  private int numDoors;
  
  public Car(double w, String m, String mo, int doors)
  {
    weight = w;
    manufacturer = m;
    model = mo;
    numDoors = doors; 
  }
  
  public String toString()
  {
    return " weight: " + weight + " manufacturer: " + 
           manufacturer + " model: " + model + " numDoors: " + numDoors;
  }
}