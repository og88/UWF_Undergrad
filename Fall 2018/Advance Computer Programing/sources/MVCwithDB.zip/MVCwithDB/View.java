/***************************************************
  Program: View.java
  Programmer: John Coffey 
  Purpose: Illustrates very simple input and output
  views as part of a MVC system.
  An obvious improvement would be to provide a 
  high-level gui so the user does not enter SQL
  queries.
 ***************************************************/
import javax.swing.JOptionPane;

class View
{
  private String[] choices = { "Show all the vehicles", 
                               "Chevies", 
                               "Dodges",
                               "Vehicles over 2501 pounds",
                               "Quit"
                             };
   public int getQuery()
   {
      String choice = (String)JOptionPane.showInputDialog(null, 
        "Select a query from the dropdown menu",
        "Issue Query on the database",
        JOptionPane.QUESTION_MESSAGE, 
        null, 
        choices, 
        choices[0]);
        if(choice == null)
          return 0;
        else if(choice.charAt(0) == 'S')
          return 1; //"Select * from Test2";
        else if(choice.charAt(0) == 'C')
          return 2; //"Select * from Test2 where manufacturer = 'Chevy'";
        else if(choice.charAt(0) == 'D')
          return 3; //"Select * from Test2 where manufacturer = 'Dodge'";
        else if(choice.charAt(0) == 'V')
          return 4; // "Select * from Test2 where weight > 2501";
        else
          return 5; //"Quit";  
}

   public void showResults(String results)
   {
      try
      {
        JOptionPane.showMessageDialog(null, results);
      }
		catch (Exception e)
		{ 
        System.out.println("query failed"); 
      }   
   }
   

   
}